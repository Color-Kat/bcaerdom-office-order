
<?php $__env->startSection('title', 'Описание БЦ Аэродом. Инфраструктура, компании-арендаторы в Аэродоме'); ?>
<?php $__env->startSection('content'); ?>
<div class="default-page block">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                                <ul class="bread-crumbs">
                            <li class="bread-crumbs__link" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                <a itemprop="url" title="БЦ Аэродом" href="/" class="">
                                    <span itemprop="title">БЦ Аэродом</span>
                                </a>
                            </li>
                            <li class="bread-crumbs__link"> / </li>
                            <li class="bread-crumbs__link" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                <a itemprop="url" title="Купить офис в БЦ Аэродом" href="/sale" class="">
                                    <?php if($data->id_typedeal == 1): ?> 
                                    Аренда
                                    <?php else: ?>
                                    Продажа
                                    <?php endif; ?>
                                    офиса в БЦ Аэродом
                                </a>
                            </li>
                            <li class="bread-crumbs__link"> / </li>
                            <li class="bread-crumbs__link bread-crumbs__link_current">Офис 
                           <?php if($data->areaMin != null && $data->areaMax != null): ?>
                            				        от <?php echo e(number_format($data->areaMin, 0, '', ' ')); ?> до <?php echo e(number_format($data->areaMax, 0, '', ' ')); ?> м<sup>2</sup>
                            				   <?php else: ?>
                            				   <?php echo e(number_format($data->areaMax, 0, '', ' ')); ?> м<sup>2</sup>
                            				    <?php endif; ?>
                              </li>
                        </ul>                   </div>
                </div>
            </div>

            <!-- Office Page -->
            <div class="office-page office-page_JS block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <span class="popup-window__headline">
                                 <?php if($data->id_typedeal == 1): ?> 
                                    Аренда
                                    <?php else: ?>
                                    Продажа
                                    <?php endif; ?>
                                    офиса в БЦ Аэродом
                                 офиса 
                                 
                                 <?php if($data->areaMin != null && $data->areaMax != null): ?>
                            				        от <?php echo e(number_format($data->areaMin, 0, '', ' ')); ?> до <?php echo e(number_format($data->areaMax, 0, '', ' ')); ?> м<sup>2</sup>
                            				   <?php else: ?>
                            				   <?php echo e(number_format($data->areaMax, 0, '', ' ')); ?> м<sup>2</sup>
                            				    <?php endif; ?>
                                  в бизнес-центре Аэродом</span>
                        </div>
                    </div>
                </div>
                <div class="popup-window__slider default-gallery-slider default-gallery-slider_JS">
                        <?php $__currentLoopData = $gals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="default-gallery-slider__cover" style="background-image: url('/public/images/gallery/<?php echo e($g->image); ?>')"></div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </div>
                <div class="container">
                    <div class="popup-window__content">
                                                <div class="row">
                            <div class="col-md-5 col-sm-7">
                                 <table class="characteristics-table">
                                            <tr>
                                                <td>Этаж:</td>
                                                <td>
                                                    <?php echo e($data->floor); ?>                                               </td>
                                            </tr>
                                            <tr>
                                                <td>Арендуемая площадь:</td>
                                                <td>
                                                    <?php if($data->areaMin != null && $data->areaMax != null): ?>
                            				        от <?php echo e(number_format($data->areaMin, 0, '', ' ')); ?> до <?php echo e(number_format($data->areaMax, 0, '', ' ')); ?> м<sup>2</sup>
                            				   <?php else: ?>
                            				   <?php echo e(number_format($data->areaMax, 0, '', ' ')); ?> м<sup>2</sup>
                            				    <?php endif; ?>
                                                    
                                                    </td>
                                            </tr>
                                                                                        <tr>
                                                <td>Готовность:</td>
                                                <td><?php echo e($data->isready); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Планировка:</td>
                                                <td><?php echo e($data->layout); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Цена:</td>
                                                <td>
                                                    <?php if($data->id_typedeal == 1): ?>
                            				            <?php if($data->price == -1): ?>
                                    				    Договорная
                                    				    <?php else: ?>
                                    				    <?php echo e(number_format(($data->price + $data->explprice), 0, '', ' ')); ?> руб. за м<sup>2</sup> / год
                                    				    <?php endif; ?>
                                    				        
                            				        <?php else: ?>
                                				        <?php if($data->price == -1): ?>
                                    				    Договорная
                                    					<?php else: ?>
                                    					
                                    					<?php echo e(number_format($data->price, 0, '', ' ')); ?> руб. за м<sup>2</sup>
                                    					<?php endif; ?>
                            				        
                            				        <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Общая стоимость:</td>
                                                <td>
                                                    <?php if($data->id_typedeal == 1): ?>
                            				           <?php if($data->price == -1): ?>
                                    				    Договорная
                                    				    <?php else: ?>
                                        				    <?php if($data->areaMin != null && $data->areaMax != null): ?>
                           
                                    					    <?php echo e(number_format((($data->price+$data->explprice+$data->explprice) / 12 * $data->areaMin), 0, '', ' ')); ?> - <?php echo e(number_format((($data->price+$data->explprice+$data->explprice) / 12 * $data->areaMax), 0, '', ' ')); ?> руб. / мес.
                                        					<?php else: ?>
                                        					    <?php echo e(number_format((($data->price+$data->explprice+$data->explprice) / 12 * $data->areaMax), 0, '', ' ')); ?> руб. / мес.
                                        					<?php endif; ?>
                                    				    <?php endif; ?>
                                    				        
                            				        <?php else: ?>
                            				            <?php if($data->price == -1): ?>
                                    				    Договорная
                                    					<?php else: ?>
                                    					<?php if($data->areaMin != null && $data->areaMax != null): ?>
                                    					 <?php echo e(number_format(($data->price * $data->areaMin), 0, '', ' ')); ?> - <?php echo e(number_format(($data->price * $data->areaMax), 0, '', ' ')); ?> руб.

                                    					<?php else: ?>
                                    					<?php echo e(number_format(($data->price * $data->areaMax), 0, '', ' ')); ?> руб.

                                    					<?php endif; ?>
        
                                    					<?php endif; ?>
                            				        
                            				        <?php endif; ?>
                                                </td>
                                            </tr>
                                             <?php if($data->id_typedeal == 1): ?>
                                             <tr>
                                                <td>Эксплуатационные расходы:</td>
                                                <?php if($data->explprice != null): ?>
                                                 <td><?php echo e(number_format($data->explprice, 0, '', ' ')); ?> за м<sup>2</sup> в год</td>
                                                <?php else: ?>
                                                 <td>Договорная</td>
                                                <?php endif; ?>
                                               
                                            </tr>
                                            <?php endif; ?>
                                                                                        <tr>
                                                <td>Налогообложение:</td>
                                                <td><?php echo e($data->name_tax); ?></td>
                                            </tr>
                                        </table>
                            </div>
                            <div class="col-md-1 col-sm-1"></div>
                            <div class="col-md-3 col-sm-4">
                                <div class="small-contacts-block small-contacts-block_colored" style="margin-bottom: 8px;padding: 15px;background: #32CD32">
                                           <a href="#" class="default-contact-call JS-get-call-popup-open whatsapp" data="whatsapp" style="border: none; font-size: 16px" 
                                            <?php if($data->areaMin != null && $data->areaMax != null): ?>
                                               dataroistat='<?php echo e($data->areaMin); ?>-<?php echo e($data->areaMax); ?> м2' datacrmId='<?php echo e($data->crmId); ?>' datatypedeal='<?php if($data->id_typedeal == 1): ?> Аренда <?php else: ?> Продажа <?php endif; ?>'>Получить презентацию в Whatsapp</a>     

                                            <?php else: ?>
                                                dataroistat='<?php echo e($data->areaMax); ?> м2' datacrmId='<?php echo e($data->crmId); ?>' datatypedeal='<?php if($data->id_typedeal == 1): ?> Аренда <?php else: ?> Продажа <?php endif; ?>'>Получить презентацию в Whatsapp</a>     

                                            <?php endif; ?>

                                        </div>
                                <div class="small-contacts-block small-contacts-block_colored">
                                    <a href="tel:+74994900592" class="default-contact-phone">+7 (499) 490-05-92</a>
                                    <a href="#" class="default-contact-call JS-get-call-popup-open" 
                                     <?php if($data->areaMin != null && $data->areaMax != null): ?>
                                               dataroistat='<?php echo e($data->areaMin); ?> - <?php echo e($data->areaMax); ?> м2' datacrmId='<?php echo e($data->crmId); ?>' datatypedeal='<?php if($data->id_typedeal == 1): ?> Аренда <?php else: ?> Продажа <?php endif; ?>'>Обратный звонок</a>   

                                            <?php else: ?>
                                                dataroistat='<?php echo e($data->areaMax); ?> м2' datacrmId='<?php echo e($data->crmId); ?>' datatypedeal='<?php if($data->id_typedeal == 1): ?> Аренда <?php else: ?> Продажа <?php endif; ?>'>Обратный звонок</a>   

                                            <?php endif; ?>
                                    
                                    
                                </div>
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h167148/data/www/bcaerodom.yemorkovin.ru/resources/views/rentsign.blade.php ENDPATH**/ ?>