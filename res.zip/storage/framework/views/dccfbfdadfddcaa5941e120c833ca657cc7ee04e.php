

<?php $__env->startSection('title', 'Админ панель'); ?>
<?php $__env->startSection('content'); ?>
<br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br /><br /><br /><br /><br /><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel/mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h167148/data/www/bcaerodom.yemorkovin.ru/resources/views/adminpanel/adminpanel.blade.php ENDPATH**/ ?>