

<?php $__env->startSection('title', 'Админ панель'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    input, select, option{
        color: #000;
        margin: 10px;
    }
    #hidebloxk{
        display: none;
        border: 1px solid #fff;
        border-radius: 4px;
        padding: 15px;
    }
    a{
        cursor: pointer;
    }
</style>
 <div class="single-product-tab-area mg-b-30" style="color: #fff; padding: 14px;">
            <!-- Single pro tab review Start-->
            <div class="single-pro-review-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="review-tab-pro-inner">
 <div class="checkbox-setting-pro" >
  <h2 style="color: #fff" align="center">Все помещения</h2>
  
    
  
                                                                           
                                                                                
                                                                               
                                                                                </form>


    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
 <div style="color: #fff; margin: 10px">Помещение №<?php echo e($d->id); ?>   
                                                                                        <?php if($d->isActive == 'on'): ?>
                                                                                            <input type="checkbox"
                                                                                             checked readonly>

                                                                                          <?php else: ?>
                                                                                          <input type="checkbox"
                                                                                             readonly>

                                                                                          <?php endif; ?>
      <a onclick="next(this)" class="has-arrow">Редактировать</a>  
        <div id="hidebloxk">
        areaMin: <input class="form-control" type="text" name="areaMin" value="<?php echo e($d->areaMin); ?>">
        areaMax: <input class="form-control" type="text" name="areaMax" value="<?php echo e($d->areaMax); ?>">
        isactive:
        <?php if($d->isActive == 'on'): ?>
                                                                                            <input type="checkbox"
                                                                                             checked name="isActive">

                                                                                          <?php else: ?>
                                                                                          <input type="checkbox"
                                                                                             name="isActive">

                                                                                          <?php endif; ?>

                                                                                          <br />
        crmId: <input class="form-control" type="number" name="crmId" value="<?php echo e($d->crmId); ?>"></td>
         <select name="type_id" class="select2_demo_3 form-control">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($type->id_type == $d->type_id): ?>
                    <option value="<?php echo e($type->id_type); ?>" selected><?php echo e($type->name_types); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($type->id_type); ?>"><?php echo e($type->name_types); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        
        floor:<input class="form-control" type="number" name="floor" value="<?php echo e($d->floor); ?>">
        price:<input class="form-control" type="text" name="price" value="<?php echo e($d->price); ?>">
        pricecur: <input class="form-control" type="text" name="pricecur" value="<?php echo e($d->pricecur); ?>">
        <select name="id_typedeal" class="select2_demo_3 form-control">
            <?php $__currentLoopData = $typedeal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($type->id_typedeal == $d->id_typedeal): ?>
                    <option value="<?php echo e($type->id_typedeal); ?>" selected><?php echo e($type->name_typedeal); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($type->id_typedeal); ?>"><?php echo e($type->name_typedeal); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="id_tax" class="select2_demo_3 form-control">
            <?php $__currentLoopData = $tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($t->id_tax == $d->id_tax): ?>
                    <option value="<?php echo e($type->id_typedeal); ?>" selected><?php echo e($t->name_tax); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($type->id_typedeal); ?>"><?php echo e($t->name_tax); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        isready: <input class="form-control" type="text" name="isready" value="<?php echo e($d->isready); ?>">
        readydate: <input class="form-control" type="text" name="readydate" value="<?php echo e($d->readydate); ?>">
        explcur: <input class="form-control" type="text" name="explcur" value="<?php echo e($d->explcur); ?>">
        explprice: <input class="form-control" type="text" name="explprice" value="<?php echo e($d->explprice); ?>">
        layout: <input class="form-control" type="text" name="layout" value="<?php echo e($d->layout); ?>">
        lastsynctime: <input class="form-control" type="text" name="lastsynctime" value="<?php echo e($d->lastsynctime); ?>">
        <input type="submit" name="" value="Обновить" class="btn btn-custon-four btn-success" />
        </div>
    </div>
</form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                                            </div>
                                            </div></div></div></div></div></div>

<script>
  function next(e){

    if(e.nextElementSibling.style.display == 'block'){
        e.nextElementSibling.style.display = 'none';
    }else{
        e.nextElementSibling.style.display = 'block';
    }

    }

    //document.addEventListener('click',e => console.log(e.target))


 
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminpanel/mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\bcaerodom\resources\views/adminpanel/plosh3.blade.php ENDPATH**/ ?>