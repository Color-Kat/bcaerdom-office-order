

<?php $__env->startSection('title', 'Админ панель'); ?>
<?php $__env->startSection('content'); ?>
<br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br /><br /><br /><br /><br /><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel/mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\bcaerodom\resources\views/adminpanel/adminpanel.blade.php ENDPATH**/ ?>