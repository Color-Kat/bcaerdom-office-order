

<?php $__env->startSection('title', 'Админ панель'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    input, select, option{
        color: #000;
        margin: 10px;
    }
    #hidebloxk{
        display: none;
        border: 1px solid #fff;
        border-radius: 4px;
        padding: 15px;
    }
    a{
        cursor: pointer;
    }
</style>
 <div class="single-product-tab-area mg-b-30" style="color: #fff; padding: 14px;">
            <!-- Single pro tab review Start-->
            <div class="single-pro-review-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="review-tab-pro-inner">
 <div class="checkbox-setting-pro" >
  <h2 style="color: #fff" align="center">Все помещения</h2>
  <h2>Выбрать помещение</h2> 
    <form method="post" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <select name="id">
            <?php $__currentLoopData = $promis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pr->id); ?>"><?php echo e($pr->name_typedeal); ?>-<?php echo e($pr->areaMax); ?>-crmId:<?php echo e($pr->crmId); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="file" name="fileUpload[]" multiple class = "input-data">
        <input type="file" name="fileUpload[]" multiple class = "input-data">
        <input type="file" name="fileUpload[]" multiple class = "input-data">
        <input type="file" name="fileUpload[]" multiple class = "input-data">
        <input type="file" name="fileUpload[]" multiple class = "input-data">
        <input type="submit" name=""> 
    </form>

    <h2>Фотографии</h2>
 <form method="post">
        <?php echo csrf_field(); ?>
        <select name="id_gal">
            <?php $__currentLoopData = $promis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pr->id); ?>"><?php echo e($pr->name_typedeal); ?>-<?php echo e($pr->areaMax); ?>-crmId:<?php echo e($pr->crmId); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div>
            <?php if(isset($gallery)): ?>
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><img src="/public/images/gallery/<?php echo e($gal->image); ?>" width="80%"> <a href="/del/?id=<?php echo e($gal->id_gallery); ?>">Удалить</a></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <input type="submit" name="select_photo">
  </form>      
                                                                            </div>
                                            </div></div></div></div></div></div>

<script>
  function next(e){

    if(e.nextElementSibling.style.display == 'block'){
        e.nextElementSibling.style.display = 'none';
    }else{
        e.nextElementSibling.style.display = 'block';
    }

    }

    //document.addEventListener('click',e => console.log(e.target))


 
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminpanel/mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h167148/data/www/bcaerodom.yemorkovin.ru/resources/views/adminpanel/galarry.blade.php ENDPATH**/ ?>