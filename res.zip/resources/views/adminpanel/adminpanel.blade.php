
@extends('adminpanel/mainadmin')
@section('title', 'Админ панель')
@section('content')
<br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br /><br /><br /><br /><br /><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br />

@endsection